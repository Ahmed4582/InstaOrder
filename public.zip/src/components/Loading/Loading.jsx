export default function Loading() {
  return (
    <div className="loading">
      <h1 className="load text-info fs-1 fw-blod text-center ">Loading...</h1>
    </div>
  );
}
