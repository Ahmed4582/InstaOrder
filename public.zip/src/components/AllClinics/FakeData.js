import img1 from "../../assets/Eye Clinic.svg";
import img2 from "../../assets/Orthopedic Clinic.svg";
import img3 from "../../assets/Neurology Clinic.svg";
import img4 from "../../assets/Dermatology clinics.svg";
import img5 from "../../assets/Dental Clinic.svg";
import img6 from "../../assets/Psychiatric clinic.svg";
import img7 from "../../assets/Ear.svg";
import img8 from "../../assets/Kids Clinic.svg";

export const CLINICS = [
  {
    id: 1,
    name: "Eye Clinic",
    image: img1,
  },
  {
    id: 2,
    name: "Orthopedic Clinic",
    image: img2,
  },
  {
    id: 3,
    name: "Neurology Clinic",
    image: img3,
  },
  {
    id: 4,
    name: "Dermatology clinics",
    image: img4,
  },
  {
    id: 5,
    name: "Dental Clinic",
    image: img5,
  },
  {
    id: 6,
    name: "Psychiatric clinic",
    image: img6,
  },
  {
    id: 7,
    name: "Ear, nose, and throat clinic",
    image: img7,
  },
  {
    id: 8,
    name: "Kids clinics",
    image: img8,
  },
  {
    id: 9,
    name: "Eye Clinic",
    image: img1,
  },
  {
    id: 10,
    name: "Orthopedic Clinic",
    image: img2,
  },
];
